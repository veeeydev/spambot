EN: 

Hey! Before running our application, make sure that the "Guna.UI.dll" file is in the same location as the application you are downloading.
Also remember that you can create a shortcut and place it wherever you want! :)


The file "Guna.UI.dll" is intended for the user interface, so do not delete it

PL: 

Hej! Przed uruchomieniem naszej aplikacji upewnij się, że plik „Guna.UI.dll” znajduje się w tej samej lokalizacji, co aplikacja, którą pobierasz.
Pamiętaj też, że możesz utworzyć skrót i umieścić go w dowolnym miejscu! :)


Plik „Guna.UI.dll” jest przeznaczony dla interfejsu użytkownika, więc nie należy go usuwać 

GER: 

Hallo! Stellen Sie vor dem Ausführen unserer Anwendung sicher, dass sich die Datei Guna.UI.dll am selben Speicherort befindet wie die Anwendung, die Sie herunterladen.
Denken Sie auch daran, dass Sie eine Verknüpfung erstellen und platzieren können, wo immer Sie möchten! :)


Die Datei "Guna.UI.dll" ist für die Benutzeroberfläche vorgesehen. Löschen Sie sie also nicht 